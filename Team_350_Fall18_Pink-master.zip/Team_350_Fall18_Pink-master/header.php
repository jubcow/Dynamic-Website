<CENTER>
                <HEADER>
                        <TITLE>Pastabilities.com</TITLE>
                </HEADER>
                <div class = "parallax">
                        <br><br>
                        <div class="title"><H1>Halt. It is time for pasta.</H1></div>
                        <br>
                        <div class="topnav">
                                <button class="active" onclick="location.href='index.php'">Home</button>
				<?php
				include 'session.php';
				if($_SESSION["login_user"] == ""){
					echo <<<EOL
					| <button onclick="location.href='register.php'">Register</button>
					| <button onclick="location.href='login.php'">Login</button>	
EOL;
                                }
				else{
					echo(" | <button onclick=\"location.href='pasta.php'\">MyPasta</button> | <button onclick=\"location.href='logout.php' \">Logout</button>");
				}
				?>
				
				
                        </div>
			<br>
</CENTER>
