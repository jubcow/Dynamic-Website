<!DOCTYPE html>
<HTML>
        <link rel = "stylesheet" href = "style.css">
	<?php include ("header.php"); ?>
	<?php include 'cred.php';?>
	<?php
        	$serverName = "localhost";
        	$db = "Team_350_Fall18_Pink";
		$connection = mysqli_connect($serverName,$username,$password,$db);
		include 'session.php';//allows for session from login to carry over

		$sql_createUser = "CREATE TABLE IF NOT EXISTS Users(
        		UserID INT NOT NULL AUTO_INCREMENT,
        		Name VARCHAR(50),
        		Pass VARCHAR(50),
        		IsAdmin INT,
        		PRIMARY KEY(UserID)
			)";
		mysqli_query($connection, $sql_createUser);
		
		$sql_createRecipe = "CREATE TABLE IF NOT EXISTS Recipe(
        		recipeID INT NOT NULL AUTO_INCREMENT,
        		Name VARCHAR(50),
        		Recipe BLOB,
        		UserID INT,
        		PRIMARY KEY(recipeID)
			ADD FOREIGN KEY(UserID) REFERENCES Users(UserID);
			)";
		mysqli_query($connection, $sql_createRecipe);
		
		$sql_createIngredient = "CREATE TABLE IF NOT EXISTS Ingredient(
        		IngredientID INT NOT NULL AUTO_INCREMENT,
        		Name VARCHAR(50),
        		PRIMARY KEY(IngredientID)
		)";
		mysqli_query($connection, $sql_createIngredient);

		$sql_createRecipe_Ingredient = "CREATE TABLE IF NOT EXISTS Recipe_Ingredient(
			IngredientID INT NOT NULL,
        		RecipeID INT NOT NULL,
        		PRIMARY KEY(IngredientID, RecipeID),
        		FOREIGN KEY(IngredientID) REFERENCES Ingredient(IngredientID),
        		FOREIGN KEY(RecipeID) REFERENCES Recipe(RecipeID)
		)";
		?>
		<div class ="mainbody">
		<?php

		if(isset($_SESSION['login_user'])){
			echo "<table><tr><td>Logged in as: ". $_SESSION["login_user"]."</td>";
			echo '<td><form method="POST" action="">
                                        <div class="userpass">
                                        <label>Search</label>
                                        <input type="text" name="keyword">
                                        <input type="submit" value="Submit">
                                </form>
                                </div></td></tr></table>';
		}
		else{
			echo "<table><tr><td>Currently logged in as Guest.  To create Pastas, <a href='register.php'>register</a> or <a href='login.php'>login</a>!</td>";

			echo '<td><form method="POST" action="">
                                        <div class="userpass">
                                        <label>Search</label>
                                        <input type="text" name="keyword">
                                        <input type="submit" value="Submit">
                                </form>
                                </div></td></tr></table>';
		}
		if($_SERVER["REQUEST_METHOD"] == "POST"){
                        $keyword = mysqli_real_escape_string($connection,$_POST["keyword"]);
                        $sql_search = "SELECT DISTINCT Recipe.Name, Recipe.Recipe FROM Recipe INNER JOIN Recipe_Ingredient ON Recipe.recipeID = Recipe_Ingredient.recipeID INNER JOIN Ingredient ON Recipe_Ingredient.IngredientID = Ingredient.IngredientID WHERE Ingredient.Name = '".$keyword."' OR Recipe.Recipe LIKE '%".$keyword."%' OR Recipe.Name LIKE '%".$keyword."%' ORDER BY Recipe.Name";
                        $searchresult = mysqli_query($connection,$sql_search);
                        //echo $sql_search;
                        $searchnum = mysqli_num_rows($searchresult);
                        //echo $searchnum;
                        if($searchnum > 0){
                                echo "<table>";
                                echo "<center><h2><u>Searched Recipes</u></h2></center>";
                                echo "<th>Name</th><th>Recipe</th>";
                                while($searchrow = mysqli_fetch_assoc($searchresult)){
                                        echo "<tr>";
                                        echo "<td>".$searchrow['Name']."</td><td>".$searchrow['Recipe']."</td>";
                                        echo "</tr>";
                                }
                                echo "</table>";
                        }
                        else{ echo "   0 Results";}
                }

		$sql_select = "SELECT Recipe.Name AS rName, Recipe, Users.Name AS author FROM Recipe INNER JOIN Users ON Recipe.UserID = Users.UserID ORDER BY rName";
                $result = mysqli_query($connection,$sql_select);
                $numRows = mysqli_num_rows($result);
                if($numRows > 0){
			echo "<table>";
			echo "<center><h2><u>All Recipes</u></h2></center>";
			echo "<th>Name</th><th>Author</th><th>Recipe</th>";
                	while($row = mysqli_fetch_assoc($result)){
				echo "<tr>";
                        	echo "<td>".$row['rName']."</td><td>".$row['author']."</td><td>".$row['Recipe']."</td>";
				echo "</tr>";
                	}
			//echo "</table></center>";
			echo "</table>";
        	}
		
		echo "<br><br><br><br><br><br></div>"
	?>	
</HTML>
