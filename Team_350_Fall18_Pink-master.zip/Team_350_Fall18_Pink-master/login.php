<!DOCTYPE html>
<html>
	<center>
	<link rel="stylesheet" href="style.css">
	<?php 
		session_start();
		
		include ("header.php");
		// Variables for connection
                include "cred.php";
                $servername = "localhost";
                $db = "Team_350_Fall18_Pink";
                $connection = mysqli_connect($servername, $username, $password, $db);
                // Create connection
	/*
                if (!$connection) {
                        echo "MySQL database connection failed.";
                } else {
                        echo "MySQL database connection success!";
                }
		echo "<br><a href='index.php'>Home</a>";
                echo "<br><br>";
          */    
		?>                                              
                <div class="mainbody">
		<?php
			if($_SERVER["REQUEST_METHOD"] == "POST"){
                        $Name = mysqli_real_escape_string($connection,$_POST["Name"]);
                        $Pass = mysqli_real_escape_string($connection,$_POST["Pass"]);
			$sql = "SELECT * FROM Users WHERE Name = '$Name' and Pass = '$Pass'";
      			$result = mysqli_query($connection,$sql);
        		$numRows = mysqli_num_rows($result);
			$row = mysqli_fetch_assoc($result);

			if($numRows == 1){
      				$Name = $row['Name']; 
				session_name("Name");
         			$_SESSION["login_user"] = $Name;//setting the session global variable
				print_r($_SESSION);
				header("location: index.php");
			}else{
				echo "<br><br><div class='redText'>Invalid</div>";
			}
   		}
	?>
	<body><br>
		<form method="POST" action="">
			<div class="userpass">
				<h1>Login</h1>
				<label>Username</label><br>
				<input type="text" name="Name"><br>
				<label>Pass</label><br>
				<input type="password" name="Pass"><br>	
			<input type="submit" value="Submit">
		</form>
		</div>
		<br><br><br><br><br><br>
	</div>
	</body>
	</center>	
</html>
