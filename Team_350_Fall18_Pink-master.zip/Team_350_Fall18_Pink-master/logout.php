<!DOCTYPE html>
<HTML>
        <link rel = "stylesheet" href = "style.css">
        <?php include ("header.php"); ?>
        <?php
                include 'session.php';//allows for session from login to carry over
		session_unset();
		header("location:index.php");
				
	?>
</HTML>
