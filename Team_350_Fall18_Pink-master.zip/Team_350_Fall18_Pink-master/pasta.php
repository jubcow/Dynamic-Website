<?php
      if($_SERVER['REQUEST_METHOD']=="POST")
      {
            header('Location:pasta.php');
      }
?>
<!DOCTYPE html>
<html>
        <center>
        <link rel="stylesheet" href="style.css">
	 <?php include 'cred.php';?>
        <?php
                $serverName = "localhost";
                $db = "Team_350_Fall18_Pink";
                $connection = mysqli_connect($serverName,$username,$password,$db);
                session_start();
                include ("header.php"); ?>
		
		<div class="mainbody">
		<?php
		echo "<center>Logged in as: ". $_SESSION["login_user"]."</center>";

		$sql_id = "SELECT UserID FROM Users WHERE Name = '".$_SESSION['login_user']."'";
		//echo $sql_id;	
		$resultID = mysqli_query($connection,$sql_id);
		$id = mysqli_fetch_assoc($resultID);
		//echo $id['UserID'];
		$sql = "SELECT Name, Recipe, UserID FROM Recipe";
                $result = mysqli_query($connection,$sql);
                $numRows = mysqli_num_rows($result);
                if($numRows > 0){
                        echo "<table>";
                        echo "<h2><u>My Pasta Recipes</u></h2>";
                        $row = mysqli_fetch_assoc($result);
			$sql_select = "SELECT recipeID, Name, Recipe, UserID FROM Recipe WHERE UserID = ".$id['UserID']."";
			//echo $id['UserID'];
			$is_admin_select = "select IsAdmin from Users where UserID=".$id['UserID']."";
			$admin = mysqli_query($connection,$is_admin_select);
			$is_admin = mysqli_fetch_assoc($admin);
			if($is_admin['IsAdmin']==1)
			{
				$sql_select = "SELECT recipeID, Name, Recipe, UserID FROM Recipe";
			}
			$result2 = mysqli_query($connection, $sql_select);
			echo "<th>Name</th><th>Recipe</th><th>Delete</th>";
			while($row2 = mysqli_fetch_assoc($result2)){
				echo "<tr>";
				echo "<td>".$row2['Name']."</td><td>".$row2['Recipe']."</td><td><form action=\"pasta.php?type=pasta&id=".$row2['recipeID']."\" method=\"post\"><button type=\"submit\">Delete</button></form></td>";
                        	echo "</tr>";
			}
                        echo "</table>";	
   }
if($is_admin['IsAdmin']==1)
{
	//$connect = mysqli_connect($serverName,$username,$password,$db);
  	$users_select = "select UserID, Name from Users where IsAdmin=0";
	$users = mysqli_query($connection,$users_select);
	//$users_results = mysqli_fetch_array($users);
  	echo "<table>";
  	echo "<h2><u>Users</u></h2>";
  	echo "<th>Name</th><th>Delete</th>";
	while($row3 = mysqli_fetch_assoc($users)){
	//foreach($users as $row3){
		echo "<tr>";
		echo "<td>".$row3['Name']."</td></td><td><form action=\"pasta.php?type=user&id=".$row3['UserID']."\" method=\"post\"><button type=\"submit\">Delete</button></form></td>";
        echo "</tr>";
	}
	echo "</table>";
}
		if($_SERVER['REQUEST_METHOD']=="POST")
		{
			if(strcmp($_GET['type'],"pasta")==0)
			{
				$delete = "delete from Recipe where recipeID=".$_GET['id']."";
				$delete2 = "delete from Recipe_Ingredient where RecipeID=".$_GET['id']."";
				for($var=0;$var<2;$var++)
				{
					mysqli_query($connection,$delete);
					mysqli_query($connection,$delete2);;
				}
			}
			else
			{
				$t1Off = "SET foreign_key_checks = 0";
			    $t1On = "SET foreign_key_checks = 1";	
				$delete = "delete from Recipe where UserID=".$_GET['id']."";
				$delete2 = "delete from Recipe_Ingredient natural join Recipe where UserID=".$_GET['id']."";
				$delete3 = "delete from Users where UserID=".$_GET['id']."";
				//echo $delete."<br>".$delete2."<br>".$delete3;
				for($var=0;$var<12;$var++)
				{
					mysqli_query($connection,$t1Off);
					mysqli_query($connection,$delete);
					mysqli_query($connection,$delete2);
					mysqli_query($connection,$delete3);
					mysqli_query($connection,$t1On);
				}	
			}
			//echo $delete;
		
		}
		?>
	<h2><a href="submit.php">Submit A Pasta</a><h2>
	<br><br><br><br><br>
	</center>
	</div>
</html>	

