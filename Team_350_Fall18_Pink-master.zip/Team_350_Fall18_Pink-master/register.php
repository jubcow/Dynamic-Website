<!DOCTYPE html>
<html>
	<link rel="stylesheet" href="style.css">
	<?php 
		session_start();
		// Variables for connection
                //include "cred.php";			// Will need credentials for mysql: username and pas
		include "header.php";
		include "cred.php";
                $servername = "localhost";
                $db = "Team_350_Fall18_Pink";
                $connection = mysqli_connect($servername, $username, $password, $db);                
	?>
<body>
<div class ="mainbody">
<br>
<form method="post" action="register.php">
		<div class="userpass">
		<div>
			<h1>Create User</h1>
			<label>Username</label><br>
			<input type="text" name="name">
		</div>
		<div>
			<label>Password</label><br>
			<input type="password" name="password">
		</div>
		<div>	
			<label>Confirm Password</label><br>
			<input type="password" name="passwordConfirm">
		</div>
		<input type="submit" value="Submit">
		</div>
	</form>
	<!--<ul>
		<li>
			<a href="get_post.php?name=Brad">Brad</a>
		</li>
		<li>
			<a href="get_post.php?name=Steve">Steve</a>
		</li>
	</ul>
	<h1><?php echo "{$name}'s Profile"; ?></h1>-->
	<?php
		if($_SERVER["REQUEST_METHOD"]=="POST")
		{
			$user = $_POST["name"];
			$pass = $_POST["password"];
			$passCon = $_POST["passwordConfirm"];
			/*echo "<p>User: " . $user . "</p>";
			echo "<p>Password: " . $pass . "</p>";
			echo "<p>Password Confirmed: " . $passCon . "</p>";
			*/		
			if(!empty($user) && !empty($pass) && !empty($passCon))
			{
				$sqlUsers = "select Name from Users";
				$users = mysqli_query($connection, $sql_select);
				$valid = 1;
				for($x=0;$x<count($users);$x++)
				{
					if(strcmp($users[$x], $user)==0)
					{
						$valid = 0;
						$x = count($users);
					}
					if($valid==1&&strcmp($pass, $passCon)==0)
					{
						/*echo "<p>User: " . $user . "</p>";
						echo "<p>Password: " . $pass . "</p>";
						echo "<p>Password Confirmed: " . $passCon . "</p>";
						*/$insert = "insert into Users (Name, Pass, IsAdmin) values('".$user."','".$pass."',0)";
						//echo "".$insert."<br>";
						mysqli_query($connection,$insert);
						echo "<p style=\"color:green\">Success!</p>";

					}
					elseif($valid==0)
					{
					echo "<div class=userpass><p style=\"color:red\">Username already exists</p></div>";	
	
					}
					elseif(strcmp($pass, $passCon)!==0)
					{
						echo "<div class=userpass><p style=\"color:red\">Passwords don't match</p></div>";	
					}

				}
			}
		}

		if($_SERVER["REQUEST_METHOD"] == "POST"){
                        $Name = mysqli_real_escape_string($connection,$_POST["name"]);
                        $Pass = mysqli_real_escape_string($connection,$_POST["password"]);
                        $sql = "SELECT * FROM Users WHERE Name = '$Name' and Pass = '$Pass'";
                        $result = mysqli_query($connection,$sql);
                        $numRows = mysqli_num_rows($result);
                        $row = mysqli_fetch_assoc($result);

                        if($numRows == 1){
                                $Name = $row['name'];
                                session_name("name");
                                $_SESSION["login_user"] = $Name;//setting the session global variable
                                print_r($_SESSION);
                                header("location: index.php");
                        }else{
                                //echo "<br><br><div class='redText'>Invalid</div>";
                        }
                }
	
	?>
<br><br><br><br>
</div>
</body>
</html>
