<?php	
	include "cred.php";
   	$servername = "localhost";
   	$db = "Team_350_Fall18_Pink";
   	$connection = mysqli_connect($servername, $username, $password, $db);
	
	session_start();
   
   	$user_check = $_SESSION['login_user'];
   
   	$ses_sql = mysqli_query($connection,"select Name from Users where Name = '$user_check' ");
   
   	$row = mysqli_fetch_assoc($ses_sql);
   
   	$login_session = $row['Name'];
   
   	//if(!isset($_SESSION['login_user'])){
      	//	header("location:login.php");
   	//}
?>
