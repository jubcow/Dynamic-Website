<!DOCTYPE html>
<html>
        <center>
        <link rel="stylesheet" href="style.css">
        <?php include 'cred.php';?>
        <?php
                $serverName = "localhost";
                $db = "Team_350_Fall18_Pink";
                $connection = mysqli_connect($serverName,$username,$password,$db);
                session_start();
                include ("header.php"); ?>
		
                <div class="mainbody">
                <?php
		echo "<center>Username: ". $_SESSION["login_user"]."</center>";
		$sql_id = "SELECT UserID FROM Users WHERE Name = '".$_SESSION['login_user']."'";
		$resultID = mysqli_query($connection,$sql_id);
                $id = mysqli_fetch_assoc($resultID);
                //echo $id['UserID'];
	
		//Finding MAX recipeID here so we know what to insert into next statement and junction table (For some reason putting NULL in the auto incrementing field for Recipe insert breaks the page...
		$sql_maxid = "SELECT MAX(RecipeID) FROM Recipe";
		$maxID = mysqli_query($connection,$sql_maxid);
		$thisid = mysqli_fetch_assoc($maxID);
		$newID = intval($thisid['MAX(RecipeID)']) + 1;


               	if($_SERVER["REQUEST_METHOD"] == "POST"){
                        $Name = mysqli_real_escape_string($connection,$_POST["Name"]);
                        $Recipe = mysqli_real_escape_string($connection,$_POST["Recipe"]);
			$Ingredient = mysqli_real_escape_string($connection,$_POST["Ingredient"]);
			$Sauce = mysqli_real_escape_string($connection,$_POST["Sauce"]);
			$Other = mysqli_real_escape_string($connection,$_POST["Other"]);  
			$sql_insert = "INSERT INTO Recipe VALUES (".$newID.",'".$Name."','".$Recipe."',".$id['UserID'].")";
			mysqli_query($connection,$sql_insert);
			
			$sql_insertIng = "INSERT INTO Recipe_Ingredient VALUES (".$Ingredient.",".$newID.")";
                        mysqli_query($connection,$sql_insertIng);

			$sql_insertSau = "INSERT INTO Recipe_Ingredient VALUES (".$Sauce.",".$newID.")";
                        mysqli_query($connection,$sql_insertSau);
		
			$sql_insertOth = "INSERT INTO Recipe_Ingredient VALUES (".$Other.",".$newID.")";
                        mysqli_query($connection,$sql_insertOth);	
			
		}
    		?>
		<form method="POST" action="" id="submission">
                        <div class="userpass">
                                <h1>Submit A Pasta</h1>
                                <label>Recipe Name</label><br>
                                <input type="text" name="Name"><br><br>
                                <label>Recipe</label><br>
				<textarea name="Recipe" rows=15 cols=50 required form="submission">Enter recipe...</textarea><br>
				<select name="Ingredient" form="submission">
  					<option value=1>Penne</option>
  					<option value=2>Spaghetti</option>
  					<option value=3>Rotini</option>
  					<option value=4>Cavatappi</option>
					<option value=9>Orzo</option>
					<option value=10>Fusilli</option>
					<option value=13>Gummy Worms</option>
					<option value=14>Bread</option>
					<option value=15>Spaggolinitini</option>
				</select>
				<select name="Sauce" form="submission">
					<option value=12>None</option>
                                        <option value=5>Ragu</option>
                                        <option value=6>Alfredo</option>
                                        <option value=7>Marinara</option>
                                        <option value=8>Ketchup</option>
					<option value=11>Oil</option>
					<option value=19>Bread</option>
					<option value=21>Pesto</option>	
                                </select>
				<select name="Other" form="submission">
					<option value=22>None</option>
                                        <option value=16>Meatballs</option>
                                        <option value=17>Bread</option>
					<option value=18>Pepperoni</option>
					<option value=20>Parmesan</option>
                                </select>

				<br>
				<input type="submit" value="Submit">
			</div>
		</form>
        <br><br><br><br><br><br><br>
        </center>
        </div>
</html>

